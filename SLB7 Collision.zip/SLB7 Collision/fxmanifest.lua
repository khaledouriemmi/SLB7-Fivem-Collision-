fx_version 'cerulean'
game 'gta5'

author 'SLB7'
description 'Car collision toggle script'
version '1.0.0'

client_script 'slb7collision.lua'
